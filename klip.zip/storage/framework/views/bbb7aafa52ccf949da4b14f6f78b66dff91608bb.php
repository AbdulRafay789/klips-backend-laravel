<section class="home-4-banner main-banner main-slider" id="banner" style="padding-top:30px;">
	<div class="swiper-container iconic-main-slider home-4-slider iconic-top-slider w-100">
		<div class="swiper-wrapper">
			<div class="swiper-slide">



		</div>
	</div>
    <div id="particles"></div>
</section><?php /**PATH D:\Wamp\www\LeukeWebPanel\resources\views/includes/topbar.blade.php ENDPATH**/ ?>