<div class='email_top_section'>
	<div class="address_sec">
		<div class="address">
			<div class="emial-social-icons">
				<a href="https://www.instagram.com/rachelallan/" target="_blank"><img width='23px' class="mobile-icon" src="{{env('APP_URL')}}/assets/imgs/instagram.png"></a>
				<a href="https://www.facebook.com/Rachel-Allan-137691512949547/" target="_blank"><img width='23px' class="mobile-icon" src="{{env('APP_URL')}}/assets/imgs/facebook.png"></a>
				<a href="https://twitter.com/@rachelallan" target="_blank"><img width='23px' class="mobile-icon" src="{{env('APP_URL')}}/assets/imgs/twitter.png"></a>
				<a href="http://www.pinterest.com/rachelallanprom/" target="_blank"><img width='23px' class="mobile-icon" src="{{env('APP_URL')}}/assets/imgs/pinterest.png"></a>
				<a href="https://rachelallan.com/blog" target="_blank"><img width='23px' class="mobile-icon" src="{{env('APP_URL')}}/assets/imgs/blogger.png"></a>
			</div>
		</div>
		<div class="email">
			<img width='20px' class="mobile-icon" src="{{env('APP_URL')}}/assets/imgs/envelope.png">&nbsp;
			<a href="mailto:info@rachelallan.com" target="_blank" style="color: #FFF;vertical-align: top;font-size: 15px;margin-right: 5px;">info@rachelallan.com</a>
		</div>
	</div>
	<div class="header_sec">
		<img class="mobile-icon" alt="Rachel Allan" title="Rachel Allan" src="{{env('APP_URL')}}/assets/imgs/email-header.jpg">
	</div>
</div>