@extends('layouts.email_company_template')
@section('content')
 {!! $data['body'] !!}
@endsection